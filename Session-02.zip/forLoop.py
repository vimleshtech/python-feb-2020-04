#for loop

for x in range(10): #from 0 to 9
    print(x)


#
for y in range(1,10,2): # 1 3 5 7 9
    print(y)
    
#print in reverse
for x in range(10,0,-1):
    print(x)
    
