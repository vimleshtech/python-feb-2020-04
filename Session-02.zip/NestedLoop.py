#nested loop : loop inside loop

''''
123
123
123
i =1 j = 1 2 3
i =2 j = 1 2 3
i =3 j = 1 2 3

'''

for i in range(1,4):
    for j in range(1,4):
        
        print(j,end='')
    print() #new line

'''
1
12
123
'''
for i in range(1,4):
    for j in range(1,i+1):
        
        print(j,end='')
    print() #new line

'''
123
12
1
'''
for i in range(1,4):
    for j in range(1,5-i):
        
        print(j,end='')
    print() #new line




    

