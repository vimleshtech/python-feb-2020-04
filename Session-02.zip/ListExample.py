sales = [111,3,4,56,67,888,44,'fff',True]
print(sales)

print('len ',len(sales))


sales = [111,3,4,56,67,888,44]
print('max ',max(sales))
print('min ',min(sales))
print('sdum ',sum(sales))

print(sales)
sales.append(100)
sales.append(1001)
print(sales)

print(sales.pop())
print(sales)


sales.sort()
print(sales)


sales.insert(3,900)
print(sales)

if 3 in sales: #find 3 in list 
    sales.remove(3) #by value    
print(sales)

#remove by index
sales.remove(sales[1])



##copy
a = sales #now if we will change data in a or sales, this will impact to other variable
a[1] =555
print(a)
print(sales)

b =sales.copy() ##now if we will change data in a or sales, this will not impact to other variable
a[1] =555
print(b)
print(sales)


#extend
a =[11,33,5]
b = [55,6,5]
b.extend(a)

c = a.copy()
c.extend(b)

#count
print(b.count(5))

      

#del sales #remove var







