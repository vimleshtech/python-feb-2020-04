#while loop series

i =1#init 
while i<=10: #condition 
    print(i)  #msg
    i =i+1 #increment / step

#print in reverse
i =10
while i>0:
    print(i,end=',') #don't chane line 
    i = i-1
    
#wap to print table of given number
x = int(input('enter data :'))
i =1
while i<=10:
    #print(x*i)
    print('{} * {} = {} '.format(x,i,x*i))
    
    i =i+1
    
#wap to get sum of all even and odd numbers between two given range
n1 = int(input('enter data '))
n2 = int(input('enter data '))

se = 0 #default value is 0
so = 0 #default value is 0
while n1<=n2:
    if n1%2 ==0: #if number is even 
        se =se+n1
    else:  #if number is odd 
        so = so+n1

    n1=n1+1


print('sum of all even ',se)
print('sum of all odd ',so)





    
    





    

