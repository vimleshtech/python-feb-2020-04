rn = int(input('enter rn'))
name = input('enter name ')
mark1 = int(input('enter mark in hindi'))
mark2 = int(input('enter mark in eng'))
mark3 = int(input('enter mark in comp'))
mark4 = int(input('enter mark in math'))
mark5 = int(input('enter mark in sci'))

phone = int(input('enter phone'))


total = mark1+mark2+mark3+mark4+mark5
avg = total/5


print('rn is {} name is {} and phone no is {} '.format(rn,name,phone))
print('total socre {} and avg is {} '.format(total,avg))






