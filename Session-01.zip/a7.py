a=int(input('enter the value of a'))
b=int(input('enter the value of b'))
c=int(input('enter the value of c'))
d=int(input('enter the value of d'))

a = a**3
b = b**3
c =c**3
d = d**3

if a+b+c ==d:
    print('condition is match')
else:
    print('condition is not match')

       



