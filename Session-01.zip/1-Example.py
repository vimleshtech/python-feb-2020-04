# file name: Hello_world.py

#print message and new line 
print('hello world, this is my first code ')

# end=''  will not change the line 
print('hi , this is first program' , end='')


n=100
print('n value is ',n)
      


