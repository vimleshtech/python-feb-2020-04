a =4
b =55

c = a+b
print('sum of a and b is c ')

print('sum of {} and {} is {} '.format(a,b,c))
print('sum of {1} and {0} is {2} '.format(a,b,c))


#error
#print('sum of {0} and {1} is {} '.format(a,b,c))



A =1
B =55.55
C ='fff'
print(' %f %d %s '%(A,B,C))




