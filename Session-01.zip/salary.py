salary=int(input('enter the salary'))
hra=0 #int(input())
da=0 #int(input())

if salary >=5000 and salary<=10000:
    hra=(salary*10)/100
    print(hra)

    da=(salary*5)/100
    print(da)

elif salary >=10001 and  salary<=15000:

    hra=(salary*15)/100
    print(hra)

    da=(salary*8)/100
    print(da)

else:
    print('out of match')
        




 
