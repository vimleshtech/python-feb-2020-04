rn = int(input('enter rn'))
name = input('enter name ')
mark = int(input('enter mark'))
phone = int(input('enter phone'))


print('rn is {} name is {} mark is {} and phone no is {} '.format(rn,name,mark,phone))



