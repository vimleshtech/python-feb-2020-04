
mark1 = int(input('enter mark in hindi'))
mark2 = int(input('enter mark in eng'))
mark3 = int(input('enter mark in comp'))
mark4 = int(input('enter mark in math'))
mark5 = int(input('enter mark in sci'))


total = mark1+mark2+mark3+mark4+mark5
avg = total/5

if avg>=60:
    print('A')
elif avg>=50:
    print('B')
elif avg>=40:
    print('C')
else:
    print('d')




