unit=int(input('enter the no of unit'))
metercharge=50
total =0

if unit <=100:
   total =(unit*40)/100+(metercharge)
   print(total)

elif unit >=200:
    total=(unit*50)/100+(metercharge)
    print(total )

elif unit>=300:
     total =(unit*60)/100+(metercharge)
     print(total)
else:
    print('out of match')
    
