
a = input()
b = input('enter data ')

print(type(a))
print(type(b))



#print
print(11)
print('hi')
